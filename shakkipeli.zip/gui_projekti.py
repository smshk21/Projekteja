"""
Elias Keso / Norssi
Opiskelijanumero: 150580881

Tämä graafinen liittymä on toimiva shakkipeli.
Tässä pelissä pätevät kaikki(!)
shakin säännöt, eli
esimerkiksi laittomia siirtoja ei pysty tekemään.
Shakkimatin sattuessa ei pysty tekemään mitään siirtoja laudalla,
vaan ainoa, mitä voi tehdä on "Lopeta peli"-napin painaminen.

Käyttäjän on oletettu osaavan shakin säännöt.
Ne voi löytää myös helposti netistä.
Esimerkiksi täältä löytyy shakin säännöt: www.shakkimatti.net/saannot.php

Käyttäjä tekee siirtoja laudalla syöttämällä ne syötekenttään muodossa
f"{lähtöruudun koordinaatti}-{kohderuudun koordinaatti}", esimerkiksi näin:
e2-e4
d8-c7
a5-h5
h8-a1
Avuksi on laudan ala- ja vasemmalla puolella numero- ja kirjainkoordinaatit.
"""

from tkinter import *

# Globaali vakio, joka sisältää kaikki mahdolliset
# shakkilaudan koordinaatit virhetarkastelua varten.
MAHDOLLISET_KOORDINAATIT = []
for kirjain in ["a", "b", "c", "d", "e", "f", "g", "h"]:
    for numero in range(1, 9):
        MAHDOLLISET_KOORDINAATIT.append(f"{kirjain}{numero}")


class shakki_käyttöliittymä:

    def __init__(self):

        self.__pääikkuna = Tk()

        # Ladataan nappuloiden kuvat luokan atribuutteihin.
        # Myöhemmin pätee myös sama nimeämisperiaate, eli
        # alussa nappulan väri (v=valkoinen, m=musta) ja sen jälkeen
        # tarkempi tieto.
        self.__vsotilas = PhotoImage(file="valkoinen_sotilas.png")
        self.__msotilas = PhotoImage(file="mustasotilas.png")
        self.__vtorni = PhotoImage(file="vtorni.png")
        self.__mtorni = PhotoImage(file="mtorni.png")
        self.__vlähetti = PhotoImage(file="vlahetti.png")
        self.__mlähetti = PhotoImage(file="mlahetti.png")
        self.__vdaami = PhotoImage(file="vdaami.png")
        self.__mdaami = PhotoImage(file="mdaami.png")
        self.__vratsu = PhotoImage(file="vratsu.png")
        self.__mratsu = PhotoImage(file="mratsu.png")
        self.__vkuningas = PhotoImage(file="vkunkku.png")
        self.__mkuningas = PhotoImage(file="mkunkku.png")

        # Tyhjä läpinäkyvä kuva samoilla mitoilla
        # tyhjien ruutujen täyttämistä varten.
        self.__tyhjä_ruutu = PhotoImage(file="tyhja.png")

        # Laudan tekemistä varten.
        ruudun_väri = 0
        sarake = 0

        # Tehdään muuttuja, joka on parillinen, jos on valkoisen vuoro
        # ja pariton jos on mustan vuoro
        self.__siirtovuoro = 0

        # Alustetaan sanakirja, johon nappuloiden sijainnit tallentuvat
        self.__ruudut = {}

        # Tehdään laudan kirjainkoordinaateista normaali ja käänteinen lista
        # tulevia silmukoita varten.
        self.__kirjain_koordinaatit = ["a", "b", "c", "d", "e", "f", "g", "h"]
        self.__kirjain_koordinaatit_rev = ["h", "g", "f", "e", "d", "c", "b", "a"]

        # Tehdään jokaisesta kirjaimesta avain toiseen sanakirjaan,
        # johon tulee avaimeksi numero ja sen hyötykuormaksi ruudun sijainti.
        # Täten sisäkkäisten sanakirjojen kaksi avainta muodostavat
        # koordinaatin shakkilaudalla, mikä helpottaa koodausta.
        for sivuttain in self.__kirjain_koordinaatit:
            self.__ruudut[sivuttain] = {}

        # Tallennetaan tiedot, minkä värisen kunkin ruudun
        # kuuluu olla.
        for sivuttain in self.__kirjain_koordinaatit:
            if ruudun_väri == 8:
                ruudun_väri = 1
            if ruudun_väri == 9:
                ruudun_väri = 0
            rivi = 1
            sarake += 1

            # Tehdään tekstikentät, jotka ovat sanakirjojen lopullinen sisältö.
            # Jokainen näistä tekstikenttä on ruutu shakkilaudalla.
            # Ruudut tehdään kätevästi kahteen sisäkkäiseen sanakirjaan, jonka
            # ensimmäine avain on koordinaatin kirjain (esim. "e" koordinaatissa
            # "e1") ja toinen koordinaatin numero ("1" in "e1"). Tämä
            # tekee kaikesta paljon helpompaa, koska ruudun sisältöön
            # pääsee täten käsiksi ruudun koordinaatilla.
            for pitkittäin in range(-9, -1):

                # Joka toisen ruudun täytyy olla valkoinen ja joka toinen musta
                if ruudun_väri % 2 == 0:
                    self.__ruudut[sivuttain][abs(pitkittäin+1)] = Label(
                        self.__pääikkuna, text="",
                        image=self.__tyhjä_ruutu,
                    background="white")
                else:
                    self.__ruudut[sivuttain][abs(pitkittäin + 1)] = Label(
                        self.__pääikkuna, text="",
                        image=self.__tyhjä_ruutu,
                        background="grey")


                self.__ruudut[sivuttain][abs(pitkittäin+1)].grid(
                    row=rivi, column=sarake, sticky=E+W+N+S)

                ruudun_väri += 1
                rivi += 1

        # Luodaan käyttäjää avustavat koordinaatit sivulle ja alle.
        numerot_sivulla = []
        kirjain_rivi = 1
        for sivulle in range(8, 0, -1):
            Label(self.__pääikkuna, text=sivulle).grid(
                row=kirjain_rivi, column=0)
            kirjain_rivi += 1

        for alle in range(1, 9):
            Label(self.__pääikkuna, text=self.__kirjain_koordinaatit[alle-1]).grid(
                row=9, column=alle)

        # Alustetaan kaikkien nappuloiden kuvat oikeille paikoilleen
        for tee in self.__kirjain_koordinaatit:
            self.__ruudut[tee][2].configure(image=self.__vsotilas)
            self.__ruudut[tee][7].configure(image=self.__msotilas)

        self.__ruudut["a"][1].configure(image=self.__vtorni)
        self.__ruudut["h"][1].configure(image=self.__vtorni)
        self.__ruudut["a"][8].configure(image=self.__mtorni)
        self.__ruudut["h"][8].configure(image=self.__mtorni)
        self.__ruudut["b"][1].configure(image=self.__vratsu)
        self.__ruudut["g"][1].configure(image=self.__vratsu)
        self.__ruudut["b"][8].configure(image=self.__mratsu)
        self.__ruudut["g"][8].configure(image=self.__mratsu)
        self.__ruudut["c"][1].configure(image=self.__vlähetti)
        self.__ruudut["f"][1].configure(image=self.__vlähetti)
        self.__ruudut["c"][8].configure(image=self.__mlähetti)
        self.__ruudut["f"][8].configure(image=self.__mlähetti)
        self.__ruudut["d"][1].configure(image=self.__vdaami)
        self.__ruudut["d"][8].configure(image=self.__mdaami)
        self.__ruudut["e"][1].configure(image=self.__vkuningas)
        self.__ruudut["e"][8].configure(image=self.__mkuningas)

        # Tehdään kaksi listaa, jotka sisältävät kummankin värin
        # kaikki nappulat,jotta voi myöhemmin
        # tarkastella siirron laillisuutta i.e. omaa nappulaa ei voi syödä
        # (esim. valkoinen nappula ei voi siirtyä toisen valkoisen
        # nappulan paikalle)
        self.__valkonappulat = [self.__ruudut["a"][2].cget("image"),
                                self.__ruudut["c"][1].cget("image"),
                                self.__ruudut["b"][1].cget("image"),
                                self.__ruudut["a"][1].cget("image")
            ,                   self.__ruudut["e"][1].cget("image"),
                                self.__ruudut["d"][1].cget("image")]

        self.__mustanappulat = [self.__ruudut["a"][7].cget("image"),
                                self.__ruudut["c"][8].cget("image"),
                                self.__ruudut["b"][8].cget("image"),
                                self.__ruudut["a"][8].cget("image")
            ,                   self.__ruudut["e"][8].cget("image"),
                                self.__ruudut["d"][8].cget("image")]

        # Tehdään lista, johon tallennetaan nappulan nimi samalla indeksillä,
        # kuin mikä se on yllä olevissa listoissa. Tämä helpottaa
        # nappulan tunnistamista myöhemmin.
        # Alkion ensimmäinen kirjain kertoo nappulan värin
        self.__nappuloiden_indeksit = ["vsotilas", "vlähetti", "vratsu", "vtorni",
                                                "vkuningas", "vdaami", "msotilas",
                                       "mlähetti", "mratsu", "mtorni", "mkuningas",
                                       "mdaami"]



        # Tehdään teksti, joka ohjeistaa käyttäjää syöttämään
        # seuraavan siirron.
        self.__siirto_teksti = Label(self.__pääikkuna, text="Valkoisen siirto:")
        self.__siirto_teksti.grid(row=4, column=10)

        # Tähän käyttäjä syöttää siirtonsa
        self.__siirtokäsky = Entry()
        self.__siirtokäsky.grid(row=5, column=10)

        # Tehdään nappi, jolla käyttäjä voi toteuttaa siirron.
        self.__siirto_nappi = Button(self.__pääikkuna,
                                    text="Toteuta siirto", command=self.siirrä)
        self.__siirto_nappi.grid(row=6, column=10)

        # Tehdään painike, jolla käyttäjä voi lopettaa pelin
        self.__lopetusnappi = Button(self.__pääikkuna,
                                     text="Lopeta peli",
                                     command=self.lopeta)
        self.__lopetusnappi.grid(row=7, column=10)

        # Tehdään tekstikenttä, jossa näytetään mahdolliset virheilmoitukset
        self.__virheilmoitus = Label(self.__pääikkuna, text="")
        self.__virheilmoitus.grid(row=5, column=11)

        # Tallennetaan tieto siitä, onko valkoisen tai
        # mustan kuningas shakissa, ja kuinka kauan se on ollut siinä.
        # Aluksi se ei tietenkään ole. Molempien kuninkaiden
        # sijainnit tarvitaan tätä varten myös.
        self.__v_shakissa1 = False
        self.__m_shakissa1 = False
        self.__v_shakissa2 = False
        self.__m_shakissa2 = False
        self.__vkunkku = "e1"
        self.__mkunkku = "e8"

        # Tehdään tekstikenttä shakkien ilmoittamista varten.
        # Aluksi voi siihen laittaa ohjeistuksen siirtojen
        # syöttämiseen.
        self.__shakki_ilmoitus = Label(self.__pääikkuna, text="Syötä "
        "siirrot muodossa (lähtöruudun koordinaatti)-(kohderuudun "
                        "koordinaatti) eli esim. d2-d4")
        self.__shakki_ilmoitus.grid(row=3, column=10)

        # Onko korotus tapahtunut
        self.__vkorotus = False
        self.__mkorotus = False
        # Korotuksen kohderuutu täytyy tallentaa, koska
        # se menee siirtokäskyyn kaksi kertaa, jolloin
        # se menetetään metodin paikalliselle muuttujalle
        self.__korotuskohde = ""

        # Ohestalyöntiä varten
        self.__toiseksi_viimeisin_siirto = ""

        # Ei saa linnottautua, jos linnottautuva
        # nappula on jo liikkunut, joten
        # tallennetaan tieto siitä, onko nappula jo liikkunut
        # lippumuuttujaan.
        self.__vkunkku_liik = False
        self.__mkunkku_liik = False
        self.__h1torni_liik = False
        self.__h8torni_liik = False
        self.__a1torni_liik = False
        self.__a8torni_liik = False


        self.__pääikkuna.mainloop()

    def siirrä(self):
        """
        Toteuttaa käyttäjän syöttämän siirron, jos se on
        korrekti.
        """
        # Korotus käsitellään erikseen
        if self.__vkorotus:
            self.korota_v()
            # Jos korotus on shakki, tarvitsee se erityiskäsittelyn.
            if self.__mkunkku in self.v_uhatut_ruudut():
                self.__m_shakissa1 = True
                self.__m_shakissa2 = True
                self.__shakki_ilmoitus.configure(text="Mustan kuningas on "
                                                      "shakissa!",
                                                 background="yellow")
            return

        # Musta tarvitsee erillisen korotuskoodin, koska korotetaan
        # musta nappula.
        if self.__mkorotus:
            self.korota_m()
            # Jos korotus on shakki, tarvitsee se erityiskäsittelyn.
            if self.__vkunkku in self.m_uhatut_ruudut():
                self.__v_shakissa1 = True
                self.__v_shakissa2 = True
                self.__shakki_ilmoitus.configure(text="Valkoisen kuningas on "
                                                      "shakissa!",
                                                 background="yellow")
            return


        # Otetaan siirron tiedot haltuun
        try:
            siirto = self.__siirtokäsky.get()
            alku, loppu = siirto.split("-")
        except ValueError:

            self.__virheilmoitus.configure(text="Virheellinen syöte!",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return

        # Jos lähtö- tai alkuruutu ei ole shakkilaudalla,
        # on syöte virheellinen.
        if alku not in MAHDOLLISET_KOORDINAATIT or \
                loppu not in MAHDOLLISET_KOORDINAATIT:
            self.__virheilmoitus.configure(text="Virheelliset koordinaatit!",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return

        # Täytyy selvittää mikä nappula (image) ruudussa on ennen
        # siirron toteuttamista. Löysin netistä tämän keinon (cget) kyseisen
        # ongelman ratkaisemiseksi.

        alku_nappula = self.__ruudut[alku[0]][int(alku[1])].cget("image")
        loppu_nappula = self.__ruudut[loppu[0]][int(loppu[1])].cget("image")

        # Linnoituksille erityiskäsittely
        if alku_nappula == self.__valkonappulat[4]:

            # Edes linnottautuessa ei voi kuningas liikkua varattujen tai
            # uhattujen ruutujuen läpi.
            if alku == "e1" and loppu == "g1" and\
                    "f1" in self.vkuningas("e1")and\
                    "g1" in self.vkuningas("f1")and not\
                    self.__vkunkku_liik and not\
                    self.__a1torni_liik:
                # Jos kuningas ei vielä ole shakissa, voidaan toteuttaa
                # siirto normaalisti.
                if not self.__v_shakissa1:
                    # Poistetaan nappula vanhasta ruudusta
                    # ja sijoitetaan se uuteen ruutuun
                    self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)
                    self.__ruudut["h"][1].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut["f"][1].configure(image=self.__vtorni)
                    # Tallennetaan kuninkaan uusi sijainti
                    self.__vkunkku = "g1"
                    self.siirtovuoro()
                    self.__siirtokäsky.delete(0, END)
                    #Nyt kuningas on liikkunut
                    self.__vkunkku_liik = True
                    return
            if alku == "e1" and loppu == "c1" and\
                "d1" in self.vkuningas("e1") and \
                    "c1" in self.vkuningas("d1")\
                and not\
                    self.__vkunkku_liik and not\
                    self.__h1torni_liik:
                # Jos kuningas ei vielä ole shakissa, voidaan toteuttaa
                # siirto normaalisti.
                if not self.__v_shakissa1:
                    # Poistetaan nappula vanhasta ruudusta
                    # ja sijoitetaan se uuteen ruutuun
                    self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)
                    self.__ruudut["a"][1].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut["d"][1].configure(image=self.__vtorni)
                    self.__vkunkku = "c1"
                    self.siirtovuoro()
                    self.__siirtokäsky.delete(0, END)
                    self.__vkunkku_liik = True
                    return
        # Lähes sama operaatio nyt mustalle
        if alku_nappula == self.__mustanappulat[4]:

            # Edes linnottautuessa ei voi kuningas liikkua varattujen tai
            # uhattujen ruutujuen läpi.
            if alku == "e8" and loppu == "g8" and\
                    "f8" in self.mkuningas("e8")and\
                    "g8" in self.mkuningas("f8")and not\
                    self.__mkunkku_liik and not\
                    self.__h8torni_liik:
                # Jos kuningas ei vielä ole shakissa, voidaan toteuttaa
                # siirto normaalisti.
                if not self.__m_shakissa1:
                    # Poistetaan nappula vanhasta ruudusta
                    # ja sijoitetaan se uuteen ruutuun
                    self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)
                    self.__ruudut["h"][8].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut["f"][8].configure(image=self.__mtorni)
                    self.__mkunkku = "g8"
                    self.siirtovuoro()
                    self.__siirtokäsky.delete(0, END)
                    self.__mkunkku_liik = True
                    return
            if alku == "e8" and loppu == "c8" and\
                "d8" in self.mkuningas("e8") and \
                    "c8" in self.mkuningas("d8")\
                and not\
                    self.__mkunkku_liik and not\
                    self.__a8torni_liik:
                # Jos kuningas ei vielä ole shakissa, voidaan toteuttaa
                # siirto normaalisti.
                if not self.__m_shakissa1:
                    # Poistetaan nappula vanhasta ruudusta
                    # ja sijoitetaan se uuteen ruutuun
                    self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)
                    self.__ruudut["a"][8].configure(image=self.__tyhjä_ruutu)
                    self.__ruudut["d"][8].configure(image=self.__mtorni)
                    self.__mkunkku = "c8"
                    self.siirtovuoro()
                    self.__siirtokäsky.delete(0, END)
                    self.__mkunkku_liik = True
                    return


        # Tallennetaan viimeisimmän siirron tiedot virhetarkastelua varten.
        # Kautta-merkki split-metodin myöhempää käyttöä varten.
        self.__viimeisin_siirto = f"{alku}/{loppu}/" \
                                  f"{alku_nappula}/{loppu_nappula}"

        # Virhetarkastelu:
        # Jos käyttäjä yrittää siirtää nappulaa, jota ei ole olemassa,
        # annetaan virheilmoitus siirtokehotuksen tekstikenttään.
        if alku_nappula == self.__tyhjä_ruutu:
            self.__virheilmoitus.configure(text="Valitsemassasi "
                                                "lähtöruudussa ei ole nappulaa",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return
        if not self.laillinen_siirto(alku_nappula):
            return


        # Jos shakissa1 on True, on kuningas pistetty shakkiin edellisellä
        # siirrolla ja siihen on pakko reagoida.
        if self.__v_shakissa1:
            self.__v_shakissa2 = True
        if self.__m_shakissa1:
            self.__m_shakissa2 = True

        # Jos kuningas ei vielä ole shakissa, voidaan toteuttaa
        # siirto normaalisti.
        if not self.__v_shakissa2 and not self.__m_shakissa2:
            # Poistetaan nappula vanhasta ruudusta
            # ja sijoitetaan se uuteen ruutuun
            self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
            self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)

        # Jos kuningas on shakissa siirron jälkeenkin,
        # on kyseessä shakin sääntöjen vastainen siirto.
        try:
            if self.__v_shakissa2 or self.__m_shakissa2:
                # Poistetaan nappula vanhasta ruudusta
                # ja sijoitetaan se uuteen ruutuun
                self.__ruudut[alku[0]][int(alku[1])].configure(image=self.__tyhjä_ruutu)
                self.__ruudut[loppu[0]][int(loppu[1])].configure(image=alku_nappula)
                if alku_nappula == self.__valkonappulat[4]:
                    self.__vkunkku = loppu
                if alku_nappula == self.__mustanappulat[4]:
                    self.__mkunkku = loppu
                # kuningas ei saisi enää olla siirron jälkeen shakissa, mutta
                # jos se on, niin ei toteuteta siirtoa vaan tehdään virheilmoitus.
                if self.__vkunkku in self.m_uhatut_ruudut() or \
                        self.__mkunkku in self.v_uhatut_ruudut():
                    raise RuntimeError
        except RuntimeError:
            # Perutaan siirto
            self.__ruudut[alku[0]][int(alku[1])].configure(image=alku_nappula)
            self.__ruudut[loppu[0]][int(loppu[1])].configure(image=loppu_nappula)
            self.__virheilmoitus.configure(text="Shakkiin täytyy reagoida!",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return

        # Shakin virhetarkastelusta päästiin läpi, joten
        # kuningas ei ole enää toista siirtoa shakissa.
        self.__v_shakissa2 = False
        self.__m_shakissa2 = False



        # Jos sotilas on päässyt viimeiselle riville, annetaan
        # korotuskehotus.
        if alku_nappula == self.__valkonappulat[0] and loppu[1] == "8":
            self.__siirto_teksti.configure(text="Korotus: Syötä [D]aami, [T]orni,"
                                                " [R]atsu tai [L]ähetti")
            self.__vkorotus = True
            self.__korotuskohde = loppu

        if alku_nappula == self.__mustanappulat[0] and loppu[1] == "1":
            self.__siirto_teksti.configure(text="Korotus: Syötä [D]aami, [T]orni,"
                                                " [R]atsu tai [L]ähetti")
            self.__mkorotus = True
            self.__korotuskohde = loppu


        # Jos liike oli kuninkaan, tallennetaan kuninkaan uusi sijainti.
        # Ja muutetaan lippumuuttuja todeksi.
        if alku_nappula == self.__valkonappulat[4]:
            self.__vkunkku = loppu
            self.__vkunkku_liik = True
        if alku_nappula == self.__mustanappulat[4]:
            self.__mkunkku = loppu
            self.__mkunkku_liik = True

        # Jos liike oli tornin, tallennetaan sen tornin liikkeen.
        # lippumuuttuja todeksi.
        if alku_nappula == self.__valkonappulat[3] and alku == "a1":
            self.__a1torni_liik = True
        if alku_nappula == self.__mustanappulat[3] and alku == "a8":
            self.__a8torni_liik = True
        if alku_nappula == self.__valkonappulat[3] and alku == "h1":
            self.__h1torni_liik = True
        if alku_nappula == self.__mustanappulat[3] and alku == "h8":
            self.__h8torni_liik = True

        # Katsotaan, onko jompikumpi kuningas shakissa
        if self.__vkunkku in self.m_uhatut_ruudut():
            self.__v_shakissa1 = True
            self.__shakkaava_nappula = loppu
            self.__shakki_ilmoitus.configure(text="Valkoisen kuningas on "
                                                  "shakissa!",
                                             background="yellow")
        else:
            self.__v_shakissa1 = False

        if self.__mkunkku in self.v_uhatut_ruudut():
            self.__m_shakissa1 = True
            self.__shakkaava_nappula = loppu
            self.__shakki_ilmoitus.configure(text="Mustan kuningas on "
                                                  "shakissa!",
                                             background="yellow")
        else:
            self.__m_shakissa1 = False

        # Poistetaan mahdollinen virheilmoitus tekstikentästä.
        if self.__virheilmoitus.cget("text") != "":
            self.__virheilmoitus.configure(text="", background="white")

        if not self.__m_shakissa1 and not self.__v_shakissa1:
            self.__shakki_ilmoitus.configure(text="",
                                             background="white")



        self.__siirtokäsky.delete(0, END)

        # Siirto on toteutettu onnistuneesti, joten tallennetaan siirto
        # toiseksi viimeisimmäksi siirroksi, jotta voidaan mahdollisesti katsoa,
        # onko ohestalyönti mahdollinen.

        self.__toiseksi_viimeisin_siirto = [alku, loppu]

        self.siirtovuoro()



    def siirtovuoro(self):
        """
        Katsoo, kumman pelaajan siirto on seuraavaksi ja
        muuttaa siirtokehotusta sen mukaisesti. Jos kyseessä on korotus,
        ei muutu siirtovuoro, sillä käyttäjän seuraava "siirto" on käsky
        siitä, miksikä nappulaksi hän haluaa sotilaansa korottaa.
        """
        if self.__siirtovuoro % 2 == 1 and not self.__vkorotus\
                and not self.__mkorotus:

            self.__siirto_teksti.configure(text="Valkoisen siirto:")

        elif self.__siirtovuoro % 2 == 0 and not self.__vkorotus\
                and not self.__mkorotus:

            self.__siirto_teksti.configure(text="Mustan siirto:")
        # Siirtovuoro ei saa muuttua, jos korotus on tapahtumassa.
        else:
            return
        self.__siirtovuoro += 1


    def lopeta(self):
        """
        Lopettaa ohjelman.
        """
        self.__pääikkuna.destroy()

    def korota_v(self):
        """
        Korottaa valkoisen sotilaan.
        """
        # Katsotaan, miksikä nappulaksi pelaaja haluaa
        # sotilaansa korottaa
        nap = self.__siirtokäsky.get()
        if nap == "D":
            self.__ruudut[self.__korotuskohde[0]][int(
                self.__korotuskohde[1])].configure(image=self.__vdaami)
            self.__vkorotus = False
            self.siirtovuoro()
            self.__siirtokäsky.delete(0, END)
            return
        elif nap == "T":
            self.__ruudut[self.__korotuskohde[0]][int(
                self.__korotuskohde[1])].configure(image=self.__vtorni)
            self.__vkorotus = False
            self.siirtovuoro()
            self.__siirtokäsky.delete(0, END)
            return
        elif nap == "R":
            self.__ruudut[self.__korotuskohde[0]][int(
                self.__korotuskohde[1])].configure(image=self.__vratsu)
            self.__vkorotus = False
            self.siirtovuoro()
            self.__siirtokäsky.delete(0, END)
            return
        elif nap == "L":
            self.__ruudut[self.__korotuskohde[0]][int(
                self.__korotuskohde[1])].configure(image=self.__vlähetti)
            self.__vkorotus = False
            self.siirtovuoro()
            self.__siirtokäsky.delete(0, END)
            return
        else:
            self.__virheilmoitus.configure(text="Syötä 'D', 'T', 'R'"
                                                " tai 'L' ")

    def korota_m(self):
        """
        Korottaa mustan sotilaan
        """
        if self.__mkorotus:
            # Katsotaan, miksikä nappulaksi pelaaja haluaa
            # sotilaansa korottaa
            nap = self.__siirtokäsky.get()
            if nap == "D":
                self.__ruudut[self.__korotuskohde[0]][int(
                    self.__korotuskohde[1])].configure(image=self.__mdaami)
                self.__mkorotus = False
                self.siirtovuoro()
                self.__siirtokäsky.delete(0, END)
                return
            elif nap == "T":
                self.__ruudut[self.__korotuskohde[0]][int(
                    self.__korotuskohde[1])].configure(image=self.__mtorni)
                self.__mkorotus = False
                self.siirtovuoro()
                self.__siirtokäsky.delete(0, END)
                return
            elif nap == "R":
                self.__ruudut[self.__korotuskohde[0]][int(
                    self.__korotuskohde[1])].configure(image=self.__mratsu)
                self.__mkorotus = False
                self.siirtovuoro()
                self.__siirtokäsky.delete(0, END)
                return
            elif nap == "L":
                self.__ruudut[self.__korotuskohde[0]][int(
                    self.__korotuskohde[1])].configure(image=self.__mlähetti)
                self.__mkorotus = False
                self.siirtovuoro()
                self.__siirtokäsky.delete(0, END)
                return
            else:
                self.__virheilmoitus.configure(text="Syötä 'D', 'T', 'R'"
                                                    " tai 'L' ")

    def laillinen_siirto(self, nappula):
        """
        Tutkii, onko käyttäjän syöttämä siirto laillinen.
        Palauttaa True, jos siirto on laillinen ja False, jos se
        ei ole laillinen
        :return: bool
        """

        # Otetaan siirron tiedot haltuun
        alku, loppu, alkunappula, loppunappula = \
            self.__viimeisin_siirto.split("/")

        # Tehdään paikallinen muuttuja, joka auttaa toiseksi
        # viimeisimmän siirron sijoituksessa
        siirto = self.__viimeisin_siirto.split("/")

        # Katsotaan, että alkuruudussa on nappula, jota siirtää
        if alkunappula not in self.__valkonappulat and \
            alkunappula not in self.__mustanappulat:

            self.__virheilmoitus.configure(text="Valitsemassasi ruudussa ei"
                                            " ole nappulaa, jota siirtää.",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return False

        # Katsotaan, että oikea pelaaja teki siirron
        if self.__siirtovuoro % 2 == 0:
            if alkunappula not in self.__valkonappulat:
                self.__virheilmoitus.configure(text="Valkoisen vuoro!",
                                               background="red")
                self.__siirtokäsky.delete(0, END)
                return False
        if self.__siirtovuoro % 2 == 1:
            if alkunappula not in self.__mustanappulat:
                self.__virheilmoitus.configure(text="Mustan vuoro!",
                                               background="red")
                self.__siirtokäsky.delete(0, END)
                return False

        # Selvitetään mikä nappula on kyseessä
        if alkunappula in self.__valkonappulat:

            # Etsitään nappula listasta
            ind = 0
            for nappula_x in self.__valkonappulat:
                if nappula_x == alkunappula:
                    # Haetaan nappulan nimi tätä varten tehdystä listasta
                    nappulan_nimi = str(self.__nappuloiden_indeksit[ind])

                ind += 1

            # Katsotaan, ettei kohderuudussa ole omaa nappulaa.
            if loppunappula in self.__valkonappulat:
                self.__virheilmoitus.configure(text="Et voi syödä omaa nappulaa",
                                                    background="red")
                self.__siirtokäsky.delete(0, END)
                return False

        # Tehdään sama homma kuin äsken, mutta mustilla nappuloilla
        if alkunappula in self.__mustanappulat:

            # Etsitään nappula listasta
            ind = 1
            for nappula_x in self.__mustanappulat:
                if nappula_x == alkunappula:
                    # Haetaan nappulan nimi tätä varten tehdystä listasta
                    nappulan_nimi = str(self.__nappuloiden_indeksit[ind + 5])

                ind += 1

            if loppunappula in self.__mustanappulat:
                self.__virheilmoitus.configure(text="Et voi syödä omaa nappulaa",
                                                    background="red")
                self.__siirtokäsky.delete(0, END)
                return False

        # Kutsutaan metodia, joka kutsuu eteenpäin nappulakohtaisen
        # metodin.
        mahdolliset_siirrot = self.kutsu(nappulan_nimi, alku)
        if loppu in mahdolliset_siirrot:
            # Siirron tekeminen onnistui, joten
            # tallennetaan siirto toiseksi viimeisimmäksi siirroksi, joka se
            # seuraavan kerran tänne tultaessa on.
            self.__toiseksi_viimeisin_siirto = siirto

            # Nyt on tehty uusi siirto, joten viimeisin siirto ei ole
            # peruttu.
            self.__peruttu = False


            return True
        else:
            self.__virheilmoitus.configure(text="Laiton siirto!",
                                           background="red")
            self.__siirtokäsky.delete(0, END)
            return False


    def kutsu(self, nappulan_nimi, lähtöruutu):
        """
        Kutsuu tietyn nappulan laillisia siirtoja tutkivaa metodia
        :param nappulan_nimi: str
        :param lähtöruutu: str
        :return: list, kaikki kyseisen nappulan lailliset siirrot
        """
        if nappulan_nimi == "vsotilas":
            self.m_uhatut_ruudut()
            return self.vsotilas(lähtöruutu)
        if nappulan_nimi == "msotilas":
            return self.msotilas(lähtöruutu)
        if nappulan_nimi == "vlähetti":
            return self.vlähetti(lähtöruutu)
        if nappulan_nimi == "mlähetti":
            return self.mlähetti(lähtöruutu)
        if nappulan_nimi == "vtorni":
            return self.vtorni(lähtöruutu)
        if nappulan_nimi == "mtorni":
            return self.mtorni(lähtöruutu)
        if nappulan_nimi == "vdaami":
            return self.vdaami(lähtöruutu)
        if nappulan_nimi == "mdaami":
            return self.mdaami(lähtöruutu)
        if nappulan_nimi == "vratsu":
            return self.vratsu(lähtöruutu)
        if nappulan_nimi == "mratsu":
            return self.mratsu(lähtöruutu)
        if nappulan_nimi == "vkuningas":
            return self.vkuningas(lähtöruutu)
        if nappulan_nimi == "mkuningas":
            return self.mkuningas(lähtöruutu)


    def vkuningas(self, lähtöruutu):
        """
        Palauttaa listassa kaikki kuninkaan mahdolliset siirrot,
        mukaanlukien linnoituksen!
        :param lähtöruutu: str
        :return: list
        """
        # Kuningas ei voi liikkua uhattuun ruutuun.
        kielletyt = self.m_uhatut_ruudut()

        # Alustetaan lista, joka palautetaan
        mahdolliset_ruudut = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = int(lähtöruutu[1])

        # Katsotaan, mikä indeksi lähtösarake on
        # kirjainkoordinaattilistassa.
        ind = self.__kirjain_koordinaatit.index(x)

        # Tehdään lista, jossa on yksi ruutu kuninkaan jokaisesta
        # suunnasta. Tätä käydään sitten for-silmukalla läpi, kun tutkitaan,
        # voiko kuningas liikkua siihen. Virheelliset ruudut (esim.e0)
        # sallitaan, koska niitä varten on erillinen virhetarkastelu
        # tämän metodin ulkopuolella.
        ruudut = []

        ruudut.append(f"{self.__kirjain_koordinaatit[ind]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y}")

        for ruutu in ruudut:
            # Seassa saattaa olla virheellisiä ruutuja, jotka
            # aiheuttavat KeyErrorin, joten taas try-except
            try:
                if self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in\
                        self.__valkonappulat and ruutu not in kielletyt:
                    mahdolliset_ruudut.append(ruutu)
            except KeyError:
                pass

        return mahdolliset_ruudut

    def mkuningas(self, lähtöruutu):
        """
        Palauttaa listassa kaikki kuninkaan mahdolliset siirrot,
        mukaanlukien linnoituksen! Lähes identtinen vkuningas-
        metodiin verrattuna
        :param lähtöruutu: str
        :return: list
        """

        # Kuningas ei voi liikkua uhattuun ruutuun.
        kielletyt = self.v_uhatut_ruudut()

        # Alustetaan lista, joka palautetaan
        mahdolliset_ruudut = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = int(lähtöruutu[1])

        # Katsotaan, mikä indeksi lähtösarake on
        # kirjainkoordinaattilistassa.
        ind = self.__kirjain_koordinaatit.index(x)

        # Tehdään lista, jossa on yksi ruutu kuninkaan jokaisesta
        # suunnasta. Tätä käydään sitten for-silmukalla läpi, kun tutkitaan,
        # voiko kuningas liikkua siihen. Virheelliset ruudut (esim.e0)
        # sallitaan, koska niitä varten on erillinen virhetarkastelu aikaisemmin.
        ruudut = []

        ruudut.append(f"{self.__kirjain_koordinaatit[ind]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y+1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind]}{y-1}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind+1]}{y}")
        ruudut.append(f"{self.__kirjain_koordinaatit[ind-1]}{y}")

        for ruutu in ruudut:
            # Seassa saattaa olla virheellisiä ruutuja, jotka
            # aiheuttavat KeyErrorin, joten taas try-except
            try:
                if self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in\
                        self.__mustanappulat and ruutu not in kielletyt:
                    mahdolliset_ruudut.append(ruutu)
            except KeyError:
                pass

        return mahdolliset_ruudut

    def m_uhatut_ruudut(self):
        """
        Palauttaa listassa kaikki tällä hetkellä mustan nappuloiden
        uhkauksen alla olevat ruudut.
        Olennainen osa kuninkaaseen liittyvissä jutuissa,
        sillä kuningas ei saa olla uhatussa ruudussa.
        :return: list
        """
        # Palautettava lista
        uhatut = []

        # Selvitetään kaikkien mustan nappuloiden sijainnit,
        # jotta voidaan kutsua kutsu-metodia, johon tarvitaan lähtöruutu
        # parametriksi.
        for kirjain in self.__kirjain_koordinaatit:
            for numero in range(1, 9):
                if self.__ruudut[kirjain][numero].cget("image") in\
                        self.__mustanappulat:
                    # Ruudussa on nappula. Selvitetään mikä nappula se on.
                    ind = self.__mustanappulat.index(self.__ruudut[kirjain]\
                                                     [numero].cget("image"))
                    nap = self.__nappuloiden_indeksit[ind+6]
                    # Kuninkaan tietoja ei tarvita
                    if nap == "mkuningas":
                        continue
                    # Sotilas voi liikkua eteenpäin, mutta ne ruudut eivät
                    # ole uhattuja, joten se tarvitsee erityiskäsittelyä.
                    # Vain kaikki sotilaan viistossa olevat ruudut ovat
                    # uhattuja.
                    if nap == "msotilas":
                        # Reunasotilaat saavat erityiskäsittelyn taas.
                        if kirjain == "a":
                            uhatut.append(f"b{numero-1}")
                            continue
                        if kirjain == "h":
                            uhatut.append(f"g{numero-1}")
                            continue
                        # Tieto sarakkeesta tarvitaan
                        sarak = self.__kirjain_koordinaatit.index(kirjain)
                        uhatut.append(f"{self.__kirjain_koordinaatit[sarak+1]}"
                                      f"{numero - 1}")
                        uhatut.append(f"{self.__kirjain_koordinaatit[sarak-1]}"
                                      f"{numero - 1}")
                        continue

                    siirrot = self.kutsu(nap, f"{kirjain}{str(numero)}")
                    uhatut += siirrot


        return uhatut

    def v_uhatut_ruudut(self):
        """
        Palauttaa listassa kaikki tällä hetkellä valkean nappuloiden
        uhkauksen alla olevat ruudut.
        Olennainen osa kuninkaaseen liittyvissä jutuissa,
        sillä kuningas ei saa olla uhatussa ruudussa.
        Lähes identtinen m_uhatut_ruudut -metodiin verrattuna
        :return: list
        """
        # Palautettava lista
        uhatut = []

        # Selvitetään kaikkien mustan nappuloiden sijainnit,
        # jotta voidaan kutsua kutsu-metodia, johon tarvitaan lähtöruutu
        # parametriksi.
        for kirjain in self.__kirjain_koordinaatit:
            for numero in range(1, 9):
                if self.__ruudut[kirjain][numero].cget("image") in\
                        self.__valkonappulat:
                    # Ruudussa on nappula. Selvitetään mikä nappula se on.
                    ind = self.__valkonappulat.index(self.__ruudut[kirjain]\
                                                     [numero].cget("image"))
                    nap = self.__nappuloiden_indeksit[ind]
                    # Kuninkaan tietoja ei tarvita
                    if nap == "vkuningas":
                        continue
                    # Sotilas voi liikkua eteenpäin, mutta ne ruudut eivät
                    # ole uhattuja, joten se tarvitsee erityiskäsittelyä.
                    # Vain kaikki sotilaan viistossa olevat ruudut ovat
                    # uhattuja.
                    if nap == "vsotilas":
                        # Reunasotilaat saavat erityiskäsittelyn taas.
                        if kirjain == "a":
                            uhatut.append(f"b{numero+1}")
                            continue
                        if kirjain == "h":
                            uhatut.append(f"g{numero+1}")
                            continue
                        # Tieto sarakkeesta tarvitaan
                        sarak = self.__kirjain_koordinaatit.index(kirjain)
                        uhatut.append(f"{self.__kirjain_koordinaatit[sarak+1]}"
                                      f"{numero + 1}")
                        uhatut.append(f"{self.__kirjain_koordinaatit[sarak-1]}"
                                      f"{numero + 1}")
                        continue

                    siirrot = self.kutsu(nap, f"{kirjain}{str(numero)}")
                    uhatut += siirrot

        return uhatut

    def vsotilas(self, lähtöruutu):
        """
        Tallentaa kaikki tietyn valkoisen sotilaan mahdolliset siirrot
        alkuasemastaan listaan, ja palauttaa sen.
        :param lähtöruutu: str, missä ruudussa nappula aluksi on
        :return: list, kaikki kyseisen nappulan lailliset siirrot
        """
        # Alustetaan (ja tyhjennetään) lista,
        # johon tallentuvat kaikki kyseisen
        # sotilaan mahdolliset siirrot.
        mahdolliset_siirrot = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = int(lähtöruutu[1])


        # Katsotaan, onko ohestalyönti mahdollinen.
        # Sitä varten otetaan ensin edellisen siirron tiedot talteen.
        # Tämä toimii kuitenkin vasta, kun vähintäänkin yksi siirto on tehty.
        if self.__siirtovuoro > 0:

            edellinen_alku = self.__toiseksi_viimeisin_siirto[0]
            edellinen_kohde = self.__toiseksi_viimeisin_siirto[1]



            # Etsitään, millä sarakkeella edellinen siirto tapahtui
            ind = self.__kirjain_koordinaatit.index(edellinen_kohde[0])

            # Etsitään, millä sarakkeella nykyinen nappula on
            ind_nap = self.__kirjain_koordinaatit.index(x)

            ohestalyönti1 = False
            # Katsotaan, onko viimeisin siirto vsotilaan viereisellä rivillä
            # ja kahden askeleen mittainen sen ohi. Ohestalyönti valkoisella
            # sotilaalla on vain mahdollinen jos kyseinen sotilas on 5.rivillä
            if y == 5:
                if int(edellinen_kohde[1]) - int(edellinen_alku[1]) == -2:
                    # Ei tahdo sisäkkäiset if-rakenteet toimia kunnolla,
                    # joten tehdään hieman rumasti.
                    ohestalyönti1 = True


                # Reunarivit käsitellään eri tavalla (koska vain toisessa
                # viistosuunnassa on ruutu.)
                if x == "a":
                    ohestalyönti1 = False
                    if self.__ruudut["b"][5].cget("image") \
                            == self.__mustanappulat[0]:
                        mahdolliset_siirrot.append("b6")
                        self.__ruudut["b"][5].configure(image="")

                if x == "h":
                    ohestalyönti1 = False
                    if self.__ruudut["g"][5].cget("image") \
                            == self.__mustanappulat[0]:
                        mahdolliset_siirrot.append("g6")
                        self.__ruudut["g"][5].configure(image="")


                # Kyseessä ei ole reunarivi, jos ohestalyönti1 == True
                if self.__ruudut[self.__kirjain_koordinaatit[ind_nap-1]][5]\
                        .cget(
                            "image")\
                        == self.__mustanappulat[0] and ohestalyönti1:
                    mahdolliset_siirrot.append(
                        f"{self.__kirjain_koordinaatit[ind_nap-1]}6")
                    self.__ruudut[self.__kirjain_koordinaatit[ind_nap - 1]][5] \
                        .configure(image="")

                # Katsotaan toinenkin viistosuunta
                if ohestalyönti1 and self.__ruudut[self.__kirjain_koordinaatit[ind_nap + 1]][5].\
                        cget(
                        "image")\
                        == self.__mustanappulat[0]:
                    mahdolliset_siirrot.append(
                        f"{self.__kirjain_koordinaatit[ind_nap+1]}6")
                    self.__ruudut[self.__kirjain_koordinaatit[ind_nap + 1]][5]. \
                        configure(image="")

        # Jos sotilas on alkuruudussaan kakkosrivillä ja molemmat
        # sen edessä olevat ruudut ovat tyhjiä,
        # saa se liikkua kaksi askelta eteenpäin.
        if str(y) == "2":
            if self.__ruudut[x][y+2].cget("image") not in self.__mustanappulat:
                    mahdolliset_siirrot.append(f"{x}{y+2}")


        # Muutoin sotilas voi liikkua edessä olevaan tyhjään ruutuun
        # tai viistossa olevaan vastustajan nappulan hallitsemaan ruutuun.
        # Ensin suoraan:
        if self.__ruudut[x][y + 1].cget("image") not in self.__mustanappulat:
            mahdolliset_siirrot.append(f"{x}{y+1}")


        # katsotaan mikä kirjain on lähtöruudun koordinaatissa
        ind = self.__kirjain_koordinaatit.index(x)


        # Varmistetaan, että kyseessä ei ole reunarivi
        if ind != 0 and ind != 7:
            # Sitten viistoon:
            if self.__ruudut[self.__kirjain_koordinaatit[ind-1]][y + 1].\
                    cget("image") in self.__mustanappulat:
                mahdolliset_siirrot.append(
                    f"{self.__kirjain_koordinaatit[ind-1]}{y+1}")

            if self.__ruudut[self.__kirjain_koordinaatit[ind+1]][y + 1].\
                    cget("image") in self.__mustanappulat:
                mahdolliset_siirrot.append(
                    f"{self.__kirjain_koordinaatit[ind+1]}{y+1}")


        # Reunariveillä vain toisessa viistosuunnassa on ruutu
        if x == "a":
            if self.__ruudut["b"][y+1].cget("image")\
                    in self.__mustanappulat:
                mahdolliset_siirrot.append(f"b{y+1}")
                #self.__ruudut["b"][y + 1].configure(image="")
        if x == "h":
            if self.__ruudut["g"][y+1].cget("image")\
                    in self.__mustanappulat:
                mahdolliset_siirrot.append(f"g{y+1}")
                #self.__ruudut["g"][y + 1].configure(image="")


        return mahdolliset_siirrot

    def msotilas(self, lähtöruutu):
        """
        Tallentaa kaikki tietyn mustan sotilaan mahdolliset siirrot
        alkuasemastaan listaan, ja palauttaa sen.
        Muuten pitkälti sama kuin vsotilas-metodi, mutta mustan sotilas
        liikkuu lautaa alaspäin.
        :param lähtöruutu: str, missä ruudussa nappula aluksi on
        :return: list, kaikki kyseisen nappulan lailliset siirrot
        """
        # Alustetaan (ja tyhjennetään) lista,
        # johon tallentuvat kaikki kyseisen
        # sotilaan mahdolliset siirrot.
        mahdolliset_siirrot = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = int(lähtöruutu[1])

        # Katsotaan, onko ohestalyönti mahdollinen.
        # Sitä varten otetaan ensin edellisen siirron tiedot talteen.
        # Tämä toimii kuitenkin vasta, kun vähintäänkin yksi siirto on tehty.
        if self.__siirtovuoro > 0:

            edellinen_alku = self.__toiseksi_viimeisin_siirto[0]
            edellinen_kohde = self.__toiseksi_viimeisin_siirto[1]

            # Etsitään, millä sarakkeella edellinen siirto tapahtui
            ind = self.__kirjain_koordinaatit.index(edellinen_kohde[0])

            # Etsitään, millä sarakkeella nykyinen nappula on
            ind_nap = self.__kirjain_koordinaatit.index(x)

            ohestalyönti1 = False
            # Katsotaan, onko viimeisin siirto vsotilaan viereisellä rivillä
            # ja kahden askeleen mittainen sen ohi. Ohestalyönti valkoisella
            # sotilaalla on vain mahdollinen jos kyseinen sotilas on 5.rivillä
            if y == 4:
                if int(edellinen_kohde[1]) - int(edellinen_alku[1]) == 2:
                    # Ei tahdo sisäkkäiset if-rakenteet toimia kunnolla,
                    # joten tehdään hieman rumasti.
                    ohestalyönti1 = True

                # Reunarivit käsitellään eri tavalla (koska vain toisessa
                # viistosuunnassa on ruutu.)
                if x == "a":
                    ohestalyönti1 = False
                    if self.__ruudut["b"][4].cget("image") \
                            == self.__valkonappulat[0]:
                        mahdolliset_siirrot.append("b3")
                        self.__ruudut["b"][4].configure(image="")

                if x == "h":
                    ohestalyönti1 = False
                    if self.__ruudut["g"][4].cget("image") \
                            == self.__valkonappulat[0]:
                        mahdolliset_siirrot.append("g3")
                        self.__ruudut["g"][4].configure(image="")

                # Kyseessä ei ole reunarivi, jos ohestalyönti1 == True
                if self.__ruudut[self.__kirjain_koordinaatit[ind_nap - 1]][4] \
                        .cget(
                    "image") \
                        == self.__valkonappulat[0] and ohestalyönti1:
                    mahdolliset_siirrot.append(
                        f"{self.__kirjain_koordinaatit[ind_nap - 1]}3")
                    self.__ruudut[self.__kirjain_koordinaatit[ind_nap - 1]][4]. \
                        configure(image="")

                # Katsotaan toinenkin viistosuunta
                if ohestalyönti1 and self.__ruudut[self.__kirjain_koordinaatit[ind_nap + 1]][4]. \
                        cget(
                    "image") \
                        == self.__valkonappulat[0]:
                    mahdolliset_siirrot.append(
                        f"{self.__kirjain_koordinaatit[ind_nap + 1]}3")
                    self.__ruudut[self.__kirjain_koordinaatit[ind_nap + 1]][4]. \
                        configure(image="")


        # Jos sotilas on alkuruudussaan seiskarivillä ja molemmat
        # sen edessä olevat ruudut ovat tyhjiä,
        # saa se liikkua kaksi askelta eteenpäin.
        if str(y) == "7":
            if self.__ruudut[x][y - 2].cget("image") \
                    not in self.__valkonappulat:
                mahdolliset_siirrot.append(f"{x}{y-2}")

        # Muutoin sotilas voi liikkua edessä olevaan tyhjään ruutuun
        # tai viistossa olevaan vastustajan nappulan hallitsemaan ruutuun.
        # Ensin suoraan:
        if self.__ruudut[x][y - 1].cget("image") not in self.__mustanappulat:
            mahdolliset_siirrot.append(f"{x}{y-1}")

        # katsotaan mikä kirjain on lähtöruudun koordinaatissa
        ind = self.__kirjain_koordinaatit.index(x)

        # Varmistetaan, että kyseessä ei ole reunarivi
        if ind != 0 and ind != 7:
            # Sitten viistoon:
            if self.__ruudut[self.__kirjain_koordinaatit[ind-1]]\
                    [y - 1].cget("image") in self.__valkonappulat:
                mahdolliset_siirrot.append(
                    f"{self.__kirjain_koordinaatit[ind-1]}{y-1}")
            if self.__ruudut[self.__kirjain_koordinaatit[ind+1]]\
                    [y - 1].cget("image") in self.__valkonappulat:
                mahdolliset_siirrot.append(
                    f"{self.__kirjain_koordinaatit[ind+1]}{y-1}")

        # Reunariveillä vain toisessa viistosuunnassa on ruutu
        if x == "a":
            if self.__ruudut["b"][y - 1].cget("image") \
                    in self.__valkonappulat:
                mahdolliset_siirrot.append(f"b{y - 1}")
        if x == "h":
            if self.__ruudut["g"][y - 1].cget("image") \
                    in self.__valkonappulat:
                mahdolliset_siirrot.append(f"g{y - 1}")

        return mahdolliset_siirrot

    def tutkiViistoSuunnat(self, numero, kirjain, alas, oikealle, valkea):
        """
        Tutkii annetusta ruudusta kaikki lailliset siirron kohderuudut
        viistosuuntaan ja palauttaa ne listassa.
        :param numero: int, ensimmäinen läpikäytävä numerokoordinaatti
        :param kirjain: int, ensimmäisen kirjainkoordinaatin indeksi
        joko kirjainkoordinaatit-listassa tai sen käänteisversiossa
        :param alas: bool, kertooko mennäänkö silmukassa lautaa alas vai ylös
        :param oikealle: bool, kertoo mennäänkö oikealle vai ei
        :param valkea: bool, kertoo kumman vuoro
        :return: list, mahdolliset siirrot
        """
        omat_nappulat = []
        vastustajan_nappulat = []
        if valkea:
            omat_nappulat = self.__valkonappulat
            vastustajan_nappulat = self.__mustanappulat
        else:
            omat_nappulat = self.__mustanappulat
            vastustajan_nappulat = self.__valkonappulat

        mahdolliset_ruudut = []
        if oikealle:
            for kirjain in self.__kirjain_koordinaatit[kirjain+1:]:
                try:
                    if alas:
                        numero -= 1
                    else:
                        numero += 1
                    if self.__ruudut[kirjain][numero].cget("image") not in\
                        omat_nappulat and self.__ruudut[kirjain][numero].cget(
                        "image") not in vastustajan_nappulat:
                        mahdolliset_ruudut.append(f"{kirjain}{numero}")
                    elif self.__ruudut[kirjain][numero].cget("image") in \
                            vastustajan_nappulat:
                        mahdolliset_ruudut.append(f"{kirjain}{numero}")
                        # Vastustajan nappulan voi syödä, mutta sen yli ei voi
                        # hypätä, joten lopetetaan silmukka.
                        break
                    else:
                        # Edessä on oma nappula
                        break
                except KeyError:
                    pass
        else:
            for kirjain in self.__kirjain_koordinaatit_rev[kirjain+1:]:
                try:
                    if alas:
                        numero -= 1
                    else:
                        numero += 1
                    if self.__ruudut[kirjain][numero].cget("image") not in\
                        vastustajan_nappulat and self.__ruudut[kirjain][numero].cget(
                        "image") not in omat_nappulat:
                        mahdolliset_ruudut.append(f"{kirjain}{numero}")
                    elif self.__ruudut[kirjain][numero].cget("image") in \
                            vastustajan_nappulat:
                        mahdolliset_ruudut.append(f"{kirjain}{numero}")
                        # Vastustajan nappulan voi syödä, mutta sen yli ei voi
                        # hypätä, joten lopetetaan silmukka.
                        break
                    else:
                        # Edessä on oma nappula
                        break
                except KeyError:
                    pass

        return mahdolliset_ruudut

    def vlähetti(self, lähtöruutu):
        """
        Palauttaa listan, jossa on kaikki kyseisen lähetin
        mahdolliset kohderuudut.
        :param lähtöruutu: str
        :return: list
        """
        mahdolliset_ruudut = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        # Katsotaan lähetin sarakkeen indeksi kirjainlistasta
        ind_nap = self.__kirjain_koordinaatit.index(x)

        # Käydään läpi jokaiseen viistosuuntaan ruudut, johon
        # lähetti voi liikkua
        numero = int(y)

        # Ensin oikeaan yläviistoon:
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, False,
                                                      True, True)

        # Oikea alaviisto:
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, True,
                                                      True, True)

        # Vasemmalle mentäessä täytyy olla käydään kirjainsarakkeita käänteisessä
        # järjestyksessä.
        ind_nap = self.__kirjain_koordinaatit_rev.index(x)
        # Vasen yläviisto
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, False,
                                                      False, True)

        # Vasen alaviisto
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, True,
                                                      False, True)

        return mahdolliset_ruudut

    def mlähetti(self, lähtöruutu):
        """
        Palauttaa listan, jossa on kaikki kyseisen lähetin
        mahdolliset kohderuudut.
        Lähes identtinen vlähetti-metodiin.
        :param lähtöruutu: str
        :return: list
        """
        mahdolliset_ruudut = []

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        # Katsotaan lähetin sarakkeen indeksi kirjainlistasta
        ind_nap = self.__kirjain_koordinaatit.index(x)

        # Käydään läpi jokaiseen viistosuuntaan ruudut, johon
        # lähetti voi liikkua
        numero = int(y)

        # Ensin oikeaan yläviistoon:
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, False,
                                                      True, False)

        # Oikea alaviisto:
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, True,
                                                      True, False)

        # Vasemmalle mentäessä täytyy olla käydään kirjainsarakkeita käänteisessä
        # järjestyksessä.
        ind_nap = self.__kirjain_koordinaatit_rev.index(x)
        # Vasen yläviisto
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, False,
                                                      False, False)

        # Vasen alaviisto
        mahdolliset_ruudut += self.tutkiViistoSuunnat(numero, ind_nap, True,
                                                      False, False)

        return mahdolliset_ruudut

    def tutkiSuoratSuunnat(self, numero, kirjain, valkea):
        """
        Palauttaa annetusta ruudusta kaikki mahdolliset kohderuudut
        suorissa suunnissa.
        :param numero: int, lähtöruudun numero
        :param kirjain: str, lähtöruudun kirjain
        :param valkea: bool, onko valkean vai mustan siirtovuoro
        :return: list, mahdolliset kohderuudut
        """
        mahdolliset_ruudut = []

        omat_nappulat = []
        vastustajan_nappulat = []
        if valkea:
            omat_nappulat = self.__valkonappulat
            vastustajan_nappulat = self.__mustanappulat
        else:
            omat_nappulat = self.__mustanappulat
            vastustajan_nappulat = self.__valkonappulat

        # Suoraan ylöspäin:
        try:
            ind = numero
            x = kirjain
            for rivi in range(ind + 1, 9):
                # Tyhjiä ruutuja
                if self.__ruudut[x][rivi].cget("image") not in \
                        omat_nappulat and self.__ruudut[x][rivi].cget(
                    "image") not in vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                # Vastustajan nappula ruudussa
                elif self.__ruudut[x][rivi].cget("image") in \
                        vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                    break
                # Oma nappula tiellä
                else:
                    break
        except KeyError:
            pass

        # Suoraan alaspäin:
        try:
            ind = numero
            x = kirjain
            for rivi in range(ind - 1, 0, -1):
                # Tyhjiä ruutuja
                if self.__ruudut[x][rivi].cget("image") not in \
                        omat_nappulat and self.__ruudut[x][rivi].cget(
                    "image") not in vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                # Vastustajan nappula ruudussa
                elif self.__ruudut[x][rivi].cget("image") in \
                        vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                    break
                # Oma nappula tiellä
                else:
                    break
        except KeyError:
            pass

        # Oikealle:
        try:
            ind = numero
            ind_nap = self.__kirjain_koordinaatit.index(kirjain)
            for x in self.__kirjain_koordinaatit[ind_nap + 1:]:
                # Tyhjiä ruutuja
                if self.__ruudut[x][ind].cget("image") not in \
                        omat_nappulat and self.__ruudut[x] \
                        [ind].cget(
                    "image") not in vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{ind}")
                # Vastustajan nappula ruudussa
                elif self.__ruudut[x][ind].cget("image") in \
                        vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{ind}")
                    break
                # Oma nappula tiellä
                else:
                    break
        except KeyError:
            pass

        # Vasemmalle:
        try:
            ind_nap = self.__kirjain_koordinaatit_rev.index(kirjain)
            rivi = numero
            for x in self.__kirjain_koordinaatit_rev[ind_nap + 1:]:
                # Tyhjiä ruutuja
                if self.__ruudut[x][rivi].cget("image") not in \
                        omat_nappulat and self.__ruudut[x] \
                        [rivi].cget(
                    "image") not in vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                # Vastustajan nappula ruudussa
                elif self.__ruudut[x][rivi].cget("image") in \
                        vastustajan_nappulat:
                    mahdolliset_ruudut.append(f"{x}{rivi}")
                    break
                # Oma nappula tiellä
                else:
                    break
        except KeyError:
            pass

        return mahdolliset_ruudut

    def mtorni(self, lähtöruutu):
        """
        Palauttaa listan kyseisen valkoisen tornin kaikista mahdollisista
        kohderuuduista. Lähes identtinen vtorni-metodiin
        :param lähtöruutu: str
        :return: list
        """

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        mahdolliset_ruudut = []

        mahdolliset_ruudut += self.tutkiSuoratSuunnat(int(y), x, False)

        return mahdolliset_ruudut

    def vtorni(self, lähtöruutu):
        """
        Palauttaa listan kyseisen valkoisen tornin kaikista mahdollisista
        kohderuuduista.
        :param lähtöruutu: str
        :return: list
        """

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        mahdolliset_ruudut = []

        mahdolliset_ruudut += self.tutkiSuoratSuunnat(int(y), x, True)

        return mahdolliset_ruudut

    def vdaami(self, lähtöruutu):
        """
        Palauttaa listan, jossa on kaikki valkoisen daamin
        mahdolliset kohderuudut.
        :param lähtöruutu: str
        :return: list
        """
        # Daami liikkuu kuin torni ja lähetti, joten katsotaan
        # mihin torni ja lähetti voisivat daamin lähtöruudusta liikkua,
        # ja yhdistetään ne kaikki daamin mahdollisiksi kohderuuduiksi.
        mahdolliset_ruudut = []
        mahdolliset_ruudut += self.vtorni(lähtöruutu)
        mahdolliset_ruudut += self.vlähetti(lähtöruutu)

        return mahdolliset_ruudut

    def mdaami(self, lähtöruutu):
        """
        Palauttaa listan, jossa on kaikki mustan daamin
        mahdolliset kohderuudut.
        :param lähtöruutu: str
        :return: list
        """
        # Daami liikkuu kuin torni ja lähetti, joten katsotaan
        # mihin torni ja lähetti voisivat daamin lähtöruudusta liikkua,
        # ja yhdistetään ne kaikki daamin mahdollisiksi kohderuuduiksi.
        mahdolliset_ruudut = []
        mahdolliset_ruudut += self.mtorni(lähtöruutu)
        mahdolliset_ruudut += self.mlähetti(lähtöruutu)

        return mahdolliset_ruudut

    def vratsu(self, lähtöruutu):
        """
        Palauttaa listassa kaikki kyseisen ratsun mahdolliset
        ruudut, johon se voi liikkua.
        :param lähtöruutu: str
        :return: list
        """

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        # Katsotaan ratsun sarakkeen indeksi kirjainkoordinaattilistasta
        ind = self.__kirjain_koordinaatit.index(x)

        # Ruudut, joihin ratsu voi liikkua
        mahdolliset_ruudut = []

        # Ruudut, joihin ratsun L-muotoinen liike johtaisi. Kaikki nämä
        # eivät välttämättä ole edes aitoja ruutuja tai sinne ei voi
        # muusta syystä liikkua. Ratsu voi parhaimmillaan liikkua
        # kahdeksaan ruutuun.
        ratsun_liike = []

        # Jos ratsu on reunoilla, tulee virhe. Jotta kaikki kelpo siirrot
        # saadaan kuitenkin tallennettua, tehdään try-except jokaiselle
        # kohdalle.
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind-1]}{int(y)+2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind+1]}{int(y)+2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind-1]}{int(y)-2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind+1]}{int(y)-2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind-2]}{int(y)+1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind-2]}{int(y)-1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind+2]}{int(y)+1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind+2]}{int(y)-1}")
        except IndexError:
            pass

        # Suodatetaan mahdollisista ruuduista tyhjät tai vastustajan
        # hallitsemat ruudut.
        for ruutu in ratsun_liike:
            try:
                if self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in\
                        self.__mustanappulat and self.__ruudut[ruutu[0]]\
                            [int(ruutu[1])].cget(
                            "image") not in self.__valkonappulat:
                    mahdolliset_ruudut.append(ruutu)
                elif self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in\
                        self.__valkonappulat:
                    mahdolliset_ruudut.append(ruutu)
            except (ValueError, KeyError):
                pass

        return mahdolliset_ruudut

    def mratsu(self, lähtöruutu):
        """
        Palauttaa listassa kaikki kyseisen ratsun mahdolliset
        ruudut, johon se voi liikkua. Lähes identtinen vratsu-
        metodin kanssa.
        :param lähtöruutu: str
        :return: list
        """

        # Jaetaan lähtöruudun tiedot helpommin muuttujiin x(lähtöruudun kirjain)
        # ja y(lähtöruudun numero). Tässä tapauksessa huono nimeäminen ei
        # sekoita, vaan selventää, koska muuten riveistä tulisi
        # kohtuuttoman pituisia tai niitä pitäisi katkoa koko ajan.
        x = lähtöruutu[0]
        y = lähtöruutu[1]

        # Katsotaan ratsun sarakkeen indeksi kirjainkoordinaattilistasta
        ind = self.__kirjain_koordinaatit.index(x)

        # Ruudut, joihin ratsu voi liikkua
        mahdolliset_ruudut = []

        # Ruudut, joihin ratsun L-muotoinen liike johtaisi. Kaikki nämä
        # eivät välttämättä ole edes aitoja ruutuja tai sinne ei voi
        # muusta syystä liikkua.
        ratsun_liike = []

        # Jos ratsu on reunoilla, tulee virhe. Jotta kaikki kelpo siirrot
        # saadaan kuitenkin tallennettua, tehdään try-except jokaiselle
        # kohdalle.
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind - 1]}{int(y) + 2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind + 1]}{int(y) + 2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind - 1]}{int(y) - 2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind + 1]}{int(y) - 2}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind - 2]}{int(y) + 1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind - 2]}{int(y) - 1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind + 2]}{int(y) + 1}")
        except IndexError:
            pass
        try:
            ratsun_liike.append(f"{self.__kirjain_koordinaatit[ind + 2]}{int(y) - 1}")
        except IndexError:
            pass

        # Suodatetaan mahdollisista ruuduista tyhjät tai vastustajan
        # hallitsemat ruudut.
        for ruutu in ratsun_liike:
            try:
                if self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in \
                        self.__mustanappulat and self.__ruudut[ruutu[0]] \
                        [int(ruutu[1])].cget(
                    "image") not in self.__mustanappulat:
                    mahdolliset_ruudut.append(ruutu)
                elif self.__ruudut[ruutu[0]][int(ruutu[1])].cget("image") not in \
                        self.__mustanappulat:
                    mahdolliset_ruudut.append(ruutu)
            except (ValueError, KeyError):
                pass

        return mahdolliset_ruudut


def main():
    shakki_käyttöliittymä()

if __name__ == '__main__':
    main()


